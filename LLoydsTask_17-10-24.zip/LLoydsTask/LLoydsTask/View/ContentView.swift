//
//  ContentView.swift
//  LLoydsTask
//
//  Created by Lakshmi Narasimha on 16/10/24.
//

import SwiftUI

struct ContentView: View {
    @StateObject var productViewModel = ProductViewModel()
    
    var body: some View {
        NavigationView {
            VStack{
                List(productViewModel.productsInfo) { product in
                    NavigationLink(destination: ProductDetailView(productImage: product.image, productTitle: product.title, productPrice: product.price)) {
                        HStack {
                            // Async image loading
                            AsyncImage(url: URL(string: product.image)) { image in
                                image
                                    .resizable()
                                    .scaledToFit()
                                    .frame(width: Constants.StringConstants.imageWidth, height: Constants.StringConstants.imageHeight)
                            } placeholder: {
                                ProgressView()
                            }
                        }
                        VStack(alignment: .leading, spacing: 5) {
                            Text(product.title)
                                .font(.headline)
                            Text(product.category.capitalized)
                                .font(.subheadline)
                                .foregroundColor(.gray)
                            Text("$\(product.price, specifier: "%.2f")")
                                .font(.body)
                                .fontWeight(.bold)
                                .foregroundColor(productViewModel.priceColor(for: product.price))
                                .font(.subheadline)
                        }
                    }
                }.listRowSpacing(15.0)
            }
            .task{
                await productViewModel.loadProducts()
            }
            .navigationTitle(Constants.StringConstants.productTitle)
        }
    }
}

#Preview {
    ContentView()
}
