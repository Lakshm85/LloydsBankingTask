//
//  Constants.swift
//  LLoydsTask
//
//  Created by Lakshmi Narasimha on 16/10/24.
//

import UIKit
import Foundation

struct Constants {
    struct StringConstants{
        static let productsUrl = "https://fakestoreapi.com/products?limit=10"
        static let productTitle = "Products"
        static let inValidURL = "Invalid URL"
        static let fetchProducts = "Fetch products"
        static let productsCount = 10
        static let imageWidth:CGFloat = 60
        static let imageHeight:CGFloat = 60
        static let WIDTH_THREE_HUNDRED:CGFloat = 300
        static let HEIGHT_THREE_HUNDRED:CGFloat = 300
        
    }
}
