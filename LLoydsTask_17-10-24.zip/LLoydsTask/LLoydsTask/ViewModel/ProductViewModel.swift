//
//  DeviceViewModel.swift
//  LLoydsTask
//
//  Created by Lakshmi Narasimha on 16/10/24.
//

import Foundation
import Combine
import SwiftUI

//MARK: ViewModel to handle data fetching
class ProductViewModel: ObservableObject {
    @Published var productsInfo: [ProductModel] = []
    @Published var errorMessage: String? = nil
    private var cancellables = Set<AnyCancellable>()
    
    //MARK: Fetch Products API Call...
    func loadProducts() async {
        guard let url = URL(string: Constants.StringConstants.productsUrl) else {
            self.errorMessage = Constants.StringConstants.inValidURL
            return
        }
        URLSession.shared.dataTaskPublisher(for: url)
            .map { $0.data }
            .decode(type: [ProductModel].self, decoder: JSONDecoder())
            .receive(on: DispatchQueue.main)
            .sink(receiveCompletion: { completion in
                switch completion {
                case .failure(let error):
                    self.errorMessage = error.localizedDescription
                case .finished:
                    break
                }
            }, receiveValue: { products in
                self.productsInfo = products
            })
            .store(in: &cancellables)
    }
    
    //MARK: Helper function to get color based on price
    func priceColor(for price: Double) -> Color {
        if price < 50 {
            return .green
        } else if price < 100 {
            return .orange
        } else {
            return .red
        }
    }
}
