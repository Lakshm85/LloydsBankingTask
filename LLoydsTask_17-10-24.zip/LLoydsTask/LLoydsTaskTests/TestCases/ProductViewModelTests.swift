//
//  ProductViewModelTests.swift
//  LLoydsTaskTests
//
//  Created by Lakshmi Narasimha on 17/10/24.
//

import XCTest
import Combine
@testable import LLoydsTask

class ProductViewModelTests: XCTestCase {
    
    var viewModel: ProductViewModel!
    var cancellables: Set<AnyCancellable>!
    
    override func setUpWithError() throws {
        viewModel = ProductViewModel()
        cancellables = []
    }
    
    override func tearDownWithError() throws {
        viewModel = nil
        cancellables = nil
    }
    
    // Test fetchProducts() to ensure the correct number of products are fetched
    func testFetchProducts() async throws {
        let expectation = XCTestExpectation(description: Constants.StringConstants.fetchProducts)
        viewModel.$productsInfo
            .dropFirst()
            .sink { products in
                XCTAssertEqual(products.count, Constants.StringConstants.productsCount)
                expectation.fulfill()
            }
            .store(in: &cancellables)
        
        await viewModel.loadProducts()
        wait(for: [expectation], timeout: TimeInterval(Constants.StringConstants.productsCount))
    }
    
    // Test priceColor() for different price ranges
    func testPriceColor() throws {
        XCTAssertEqual(viewModel.priceColor(for: 30), .green)
        XCTAssertEqual(viewModel.priceColor(for: 75), .orange)
        XCTAssertEqual(viewModel.priceColor(for: 150), .red)
    }
}
